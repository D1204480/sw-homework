package org.example;

import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggingFile {

  // 一般都是用 class name 來作為 logger 的名字
  public static final Logger logger = Logger.getLogger(LoggingFile.class.getName());

}
